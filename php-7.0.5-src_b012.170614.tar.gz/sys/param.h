#ifndef SYS_PARAM_H
#define SYS_PARAM_H

/* z/OS XL C/C++ has no sys/param.h */

#endif /* SYS_PARAM_H */
