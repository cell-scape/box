#ifndef USS_PORT_DEBUG_H
#define USS_PORT_DEBUG_H

#ifdef USS_PORT_DEBUG
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

extern char** environ;

#define USS_PORT_DEBUG_FILE "/u/tsavk/ussport_ascii/php/php_build.debug/sapi/cgi/uss_port_debug.out"

#define USS_PORT_DEBUG_PRINT_HEAD(msg) uss_port_debug_print_head(msg, __FILE__, __func__, __LINE__)
inline void uss_port_debug_print_head(const char* msg, const char* file, const char* func, int line)
{
/*    FILE* debug_f = stderr; */
    FILE* debug_f = NULL;
    if (debug_f = fopen(USS_PORT_DEBUG_FILE, "a"))
    {
        fprintf(debug_f, "%d: %s: %s: %d: %s\n", getpid(), file, func, line, msg ? msg : "");
        fflush(debug_f);
        fclose(debug_f);
    }
}

#define USS_PORT_DEBUG_PRINT_ARGV(msg, argv) uss_port_debug_print_argv(msg, argv, __FILE__, __func__, __LINE__)
inline void uss_port_debug_print_argv(const char* msg, char** argv, const char* file, const char* func, int line)
{
    uss_port_debug_print_head(msg, file, func, line);
    FILE* debug_f = NULL;
    fprintf(debug_f, "program arguments:\n");
    if (debug_f = fopen(USS_PORT_DEBUG_FILE, "a"))
    {
        for (char** p = argv; *p; *p++)
        {
            fprintf(debug_f, "%s\n", *p);
        }
        fflush(debug_f);
        fclose(debug_f);
    }
}

#define USS_PORT_DEBUG_PRINT_ENV(msg) uss_port_debug_print_env(msg, __FILE__, __func__, __LINE__)
inline void uss_port_debug_print_env(const char* msg, const char* file, const char* func, int line)
{
    uss_port_debug_print_head(msg, file, func, line);
    FILE* debug_f = NULL;
    fprintf(debug_f, "environment variables:\n");
    if (debug_f = fopen(USS_PORT_DEBUG_FILE, "a"))
    {
        for (char** p = environ; *p; *p++)
        {
            fprintf(debug_f, "%s\n", *p);
        }
        fflush(debug_f);
        fclose(debug_f);
    }
}


#define USS_PORT_DEBUG_PRINT_ID(msg) uss_port_debug_print_id(msg, __FILE__, __func__, __LINE__)
inline void uss_port_debug_print_id(const char* msg, const char* file, const char* func, int line)
{
/*    char buf_user_id[L_cuserid];
    char* user_id = cuserid(buf_cuser_id);
    uss_port_debug_print_head(msg);
    fprintf(stderr, "termid=%s, userid=%s, euid=%d, ruid=%d, egid=%d, rgid=%d\n", 
        ctermid(NULL), 
        buf_user_id,
        geteuid(), 
        getuid(), 
        getegid(), 
        getgid());
*/
    uss_port_debug_print_head(msg, file, func, line);
    fprintf(stderr, "termid=%s, euid=%d, ruid=%d, egid=%d, rgid=%d\n", 
        ctermid(NULL), 
        geteuid(), 
        getuid(), 
        getegid(), 
        getgid());
}

#define USS_PORT_DEBUG_PRINT_CVT(msg, fd) uss_port_debug_print_cvt(msg, fd, __FILE__, __func__, __LINE__)
inline void uss_port_debug_print_cvt(const char* msg, int fd, const char* file, const char* func, int line)
{
    uss_port_debug_print_head(msg, file, func, line);
    FILE* debug_f = NULL;
    if (debug_f = fopen(USS_PORT_DEBUG_FILE, "a"))
    {
        int r;
        struct f_cnvrt cvt;
        cvt.pccsid = 0;
        cvt.fccsid = 0;
        cvt.cvtcmd = QUERYCVT;
        r = fcntl(fd, F_CONTROL_CVT, &cvt);
        if (r == -1)
        {
            fprintf(debug_f, "fcntl error\n");
        }
	else
	{
	    fprintf(debug_f, "fd = %d\npccsid = %d\nfccsid = %d\ncvtcmd = %d\n", 
		fd, cvt.pccsid, cvt.fccsid, cvt.cvtcmd);
	}
        fflush(debug_f);
        fclose(debug_f);
    }
}

#if 1

/*
c99 -Wc,lp64 -o show_info show_info.c
cp -pm show_info ~/
 */

#define _POSIX_SOURCE 1
#define _OPEN_SYS_FILE_EXT 1
#define _OPEN_SYS_PTY_EXTENSIONS 1
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <pwd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <termios.h>

extern char **environ;

struct buffer {
  char *data;
  int size;
  char *buffer;
  int remaining;
};

static struct buffer *make_buffer()
{
  return (struct buffer *)calloc(1, sizeof(struct buffer));
}

static void free_buffer(struct buffer *buffer)
{
  if (buffer->data) free(buffer->data);
  free(buffer);
}

static void print_to_buffer(struct buffer *buffer, char *format, ...)
{
  int expand = 1024;
  if (buffer->remaining < expand) {
    int new_size = buffer->size + expand;
    int new_remaining = buffer->remaining + expand;
    char *new_data = malloc(new_size);
    if (new_data == NULL) return;
    if (buffer->data) {
      memcpy(new_data, buffer->data, buffer->size);
      free(buffer->data);
    } else {
      new_data[0] = 0;
    }
    buffer->data = new_data;
    buffer->size = new_size;
    buffer->remaining = new_remaining;
    buffer->buffer = buffer->data + (buffer->size - buffer->remaining);
  }
  va_list ap;
  va_start(ap, format);
  int count = vsnprintf(buffer->buffer, buffer->remaining, format, ap);
  va_end(ap);
  if (count >= 0) {
    buffer->buffer += count;
    buffer->remaining -= count;
  }
}

static void write_buffer(struct buffer *buffer, int fd)
{
  int remaining = buffer->size - buffer->remaining;
  char *data = buffer->data;
  while (remaining > 0) {
    int n = write(fd, data, remaining);
    if (n == 0) break;
    if (n < 0) {
      if (errno == EINTR) continue;
      break;
    }
    data += n;
    remaining -= n;
  }
  buffer->remaining = buffer->size;
  buffer->buffer = buffer->data;
}

static void show_fd(struct buffer *buffer, int fd)
{
  int getfd_result = fcntl(fd, F_GETFD, NULL);
  if (getfd_result >= 0) {
    int getfl_result = fcntl(fd, F_GETFL, NULL);
    struct f_cnvrt fc = {.cvtcmd = QUERYCVT, .pccsid=0, .fccsid=0};
    int ccvt_result = fcntl(fd, F_CONTROL_CVT, &fc);
    char *cvtcmd = (0 > ccvt_result) ? "unknown" :
      (fc.cvtcmd==SETCVTON)?"ON":(fc.cvtcmd==SETCVTOFF)?"OFF":(fc.cvtcmd==SETCVTALL)?"ALL":"?";
    print_to_buffer(buffer, "\nfd=%d, getfd=%X, getfl=%X, cvt=%s, pccsid=%d, fccsid=%d\n",
		    fd, getfd_result, getfl_result, cvtcmd, fc.pccsid, fc.fccsid);
    struct stat st;
    int fstat_result = fstat(fd, &st);
    if (0 == fstat_result) {
      char *type =
	S_ISREG(st.st_mode) ? "regular" : 
	S_ISFIFO(st.st_mode) ? "pipe" :
	S_ISCHR(st.st_mode) ? "tty" :
	S_ISBLK(st.st_mode) ? "block" :
	S_ISDIR(st.st_mode) ? "directory" :
	S_ISLNK(st.st_mode) ? "link" :
	S_ISSOCK(st.st_mode) ? "socket" :
	"other";
      print_to_buffer(buffer, "fstat: mode=%X, type=%s, tag=%d, ccsid=%d, size=%d\n",
		      st.st_mode, type, st.st_tag.ft_txtflag, st.st_tag.ft_ccsid, st.st_size);
      if (S_ISCHR(st.st_mode)) {
	char *name = ttyname(fd);
        struct __termcp termcp;
	int cpcn_capability;
	memset (&termcp, 0, sizeof (termcp));
	cpcn_capability = __tcgetcp (fd, sizeof(termcp), &termcp);
	char *capability_name =
	  (cpcn_capability == _CPCN_NAMES) ? "names" :
	  (cpcn_capability == _CPCN_TABLES) ? "tables" :
	  "unknown";
	print_to_buffer(buffer, "ttyname=%s, cpcn=%s, fastp=%s, binary=%s, fromname=%s, toname=%s\n",
			name, capability_name,
			(termcp.__tccp_flags & _TCCP_FASTP) ? "on" : "off",
			(termcp.__tccp_flags & _TCCP_BINARY) ? "on" : "off",
			termcp.__tccp_fromname, termcp.__tccp_toname);
      }
    }
  }
}

static int show_info(int argc, char **argv)
{
  struct buffer *buffer = make_buffer();
  struct timeval tv;
  if (0 == gettimeofday(&tv, NULL)) {
    struct tm *tm = localtime(&tv.tv_sec);
    if (tm) {
      print_to_buffer(buffer, "time=%04d-%02d-%02d %02d:%02d:%02d.%06d\n",
		      tm->tm_year+1900, tm->tm_mon, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec, tv.tv_usec);
    }
  }
  {
    char cwd_buffer[4096];
    char *cwd = getcwd(cwd_buffer, sizeof(cwd_buffer));
    if (cwd == NULL)
      print_to_buffer(buffer, "getcwd failed: %s\n", strerror(errno));
    else
      print_to_buffer(buffer, "cwd=%s\n", cwd);
  }
  print_to_buffer(buffer, "pid=%d, ppid=%d, sid=%d\n", getpid(), getppid(), getsid(getpid()));
  int uid = getuid();
  print_to_buffer(buffer, "uid=%d\n", uid);
  struct passwd *pw = getpwuid(uid);
  char *HOME = NULL;
  if (pw == NULL)
    print_to_buffer(buffer, "getpwuid failed: %s\n", strerror(errno));
  else {
    print_to_buffer(buffer, "name=%s\n", pw->pw_name);
    print_to_buffer(buffer, "dir=%s\n", pw->pw_dir);
    print_to_buffer(buffer, "shell=%s\n", pw->pw_shell);
    HOME = pw->pw_dir;
  }
  for (int i=0; i<64; i++) {
    show_fd(buffer, i); 
  }
  print_to_buffer(buffer, "\n");
  for (int i=0; i<argc; i++) {
    print_to_buffer(buffer, "argv[%d]=%s\n", i, argv[i]);
  }
  print_to_buffer(buffer, "\n");
  for (int i=0; environ[i]; i++) {
    print_to_buffer(buffer, "env: %s\n", environ[i]);
  }
  print_to_buffer(buffer, "\n\n");
  char outfile_name[4096];
  snprintf(outfile_name, sizeof(outfile_name), "%s/show_info.out", HOME ? HOME : "/tmp");
  int out_fd = open(outfile_name, O_WRONLY + O_CREAT + O_APPEND, S_IRWXU + S_IRGRP + S_IROTH);
  if (out_fd == -1)
    return 2;
  struct file_tag st_tag;
  memset(&st_tag, 0, sizeof(st_tag));
  st_tag.ft_txtflag = 1;
  st_tag.ft_ccsid = 1047;
  fcntl(out_fd, F_SETTAG, &st_tag);
  write_buffer(buffer, out_fd);
  close(out_fd);
  free_buffer(buffer);
  return 0;
}

#endif /* 0/1 */

#else /* !USS_PORT_DEBUG */

#define USS_PORT_DEBUG_PRINT_HEAD(msg)
#define USS_PORT_DEBUG_PRINT_ARGV(msg, argv)
#define USS_PORT_DEBUG_PRINT_ENV(msg)
#define USS_PORT_DEBUG_PRINT_ID(msg)
#define USS_PORT_DEBUG_PRINT_CVT(msg, fd)

#endif /* USS_PORT_DEBUG */

#endif /* USS_PORT_DEBUG_H */
