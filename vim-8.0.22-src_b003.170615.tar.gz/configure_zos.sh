#!/bin/env bash

######################### VARIABLES ##########################################
PREFIX="/rsusr/rocket"


CC="c99"
OFLAGS="-O"
QFLAGS="-qlanglvl=extended:extc89:extc99 -qxplink -qdll \
-qfloat=ieee -qlongname -qenum=int -qhaltonmsg=3296:4108"
DFLAGS="-D_ALL_SOURCE -D_EXT -D_UNIX03_SOURCE -D_XOPEN_SOURCE_EXTENDED=1 \
-D_ISOC99_SOURCE -D_OE_SOCKETS -D_OPEN_MSGQ_EXT -D_OPEN_SYS \
-D_OPEN_THREADS -D_POSIX_SOURCE -D_SHARE_EXT_VARS -D_UNIX03_SOURCE \
-D_UNIX03_WITHDRAWN -D_XOPEN_SOURCE=600 -D_OPEN_SYS_FILE_EXT=1"

CFLAGS="${OFLAGS} ${QFLAGS}"

QLFLAGS="-qxplink -qdll"
LDFLAGS="${OFLAGS} ${QLFLAGS}"
CPP="cpp"
CPPFLAGS="${DFLAGS}"

#X_INCLUDES='/usr/lpp/tcpip/X11R66/include'
#X_LIBRARIES='/usr/lpp/tcpip/X11R66/lib'

######################### MAIN ###############################################
./configure --prefix=${PREFIX} CC=${CC} CFLAGS="${CFLAGS}" LDFLAGS="${LDFLAGS}" \
CPP=${CPP} CPPFLAGS="${CPPFLAGS}" --with-features=big \
--without-x --enable-gui=no --with-tlib=curses

#--x-includes=${X_INCLUDES} --x-libraries=${X_LIBRARIES}

exit 0
##############################################################################
