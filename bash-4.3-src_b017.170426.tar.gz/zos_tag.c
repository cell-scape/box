/* zos_tag.c -- Functions to manipulate tag files in z/OS */

/* Copyright (C) 201 RocketSoftware, Inc.

   This file is part of GNU Bash, the Bourne Again SHell.

   Bash is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Bash is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Bash.  If not, see <http://www.gnu.org/licenses/>.
*/

/* **************************************************************** */

#include <_Ccsid.h>
#include <stdarg.h>
#include <_Nascii.h>

#define CCSID_ISO8859_1       ((__ccsid_t) 819)
#define CCSID_IBM_1047        ((__ccsid_t) 1047)


/* **************************************************************** */

#if DEBUG_ZOS

static int fd_zos = -1;

static void close_fd_zos(void)
{
	if(fd_zos != -1){
		fsync(fd_zos);
		close(fd_zos);
	}	
}

static int init_debug(void)
{
	char name[] = "/tmp/bash.0000000000.debug.log";
	sprintf(name,"/tmp/bash.%010d.debug.log",getpid());
	fd_zos = open(name,O_RDWR|O_CREAT|O_TRUNC,S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);
	if(fd_zos != -1){
		struct file_tag ft;
		ft.ft_ccsid = CCSID_ISO8859_1;
		ft.ft_txtflag = 1;
		ft.ft_deferred = 1;
		fcntl(fd_zos, F_SETTAG, &ft);
		atexit(close_fd_zos);
	}
	return fd_zos;
}

#define LEN_INFO     256
static char info_zos[LEN_INFO];

int write_debug_zos(const char * str,...)
{
	va_list arg;
	size_t len;
	va_start(arg,str);

	if(fd_zos != -1){
		vsnprintf(info_zos,LEN_INFO,str,arg);
		len = strlen(info_zos);
		write(fd_zos,info_zos,len);
	}

	va_end(arg);
	return 0;
}

#else
#define init_debug()                ;
#endif 

static int query_attr(int fd,struct f_cnvrt * cvt)
{
	cvt->pccsid = 0;
	cvt->fccsid = 0;
	cvt->cvtcmd = QUERYCVT;

	return fcntl(fd,F_CONTROL_CVT,cvt);
}

static int set_attr_stdio(int fd)
{
	int rc = 0; 
	struct f_cnvrt cvt;

	rc = query_attr(fd,&cvt);
	write_debug_zos("query %d rc: %d | pccsid: %04d | fccsid: %04d\n",fd,rc,cvt.pccsid,cvt.fccsid);
	if(rc == 0){
		if(cvt.fccsid == FT_UNTAGGED){
			cvt.pccsid = 0;
			cvt.fccsid = CCSID_IBM_1047;
			cvt.cvtcmd = SETCVTON;
			rc = fcntl(fd,F_CONTROL_CVT,&cvt);
			write_debug_zos("contl %d rc: %d | pccsid: %04d | fccsid: %04d\n",fd,rc,cvt.pccsid,cvt.fccsid);
		}
	}
	return rc;
}

int init_attr_stdio(void)
{
	int rc;
	init_debug();
	rc = __ae_autoconvert_state(_CVTSTATE_ON);
	write_debug_zos("auotoconvert : %d\n",rc);
	set_attr_stdio(STDIN_FILENO);
	set_attr_stdio(STDOUT_FILENO);
	set_attr_stdio(STDERR_FILENO);

	return 0;
}

/* **************************************************************** */

static __ccsid_t ccsid_new = CCSID_ISO8859_1;
static char OPTION_CCSID_NEW[] = "_ENCODE_FILE_NEW";
static __ccsid_t ccsid_all = FT_UNTAGGED;
static char OPTION_CCSID_ALL[] = "_ENCODE_FILE_EXISTING";
static __ccsid_t ccsid_pipe = CCSID_ISO8859_1;
static char OPTION_CCSID_PIPE[] = "_ENCODE_PIPE";
static char NAME_UNTAGGED[] = "UNTAGGED";
static char NAME_BINARY[] = "BINARY";

static int check_env_ccsid(void)
{
	int rc;
	__ccsid_t ccsid;
	char * option = NULL;

	option = getenv(OPTION_CCSID_NEW);
	if(option == NULL){
		ccsid_new = CCSID_ISO8859_1;
	}
	else{
		ccsid = __toCcsid(option);
		if(ccsid != 0){
			ccsid_new = ccsid;
		}
		else{
			rc = strcmp(option,NAME_UNTAGGED);
			if(rc == 0){
				ccsid_new = FT_UNTAGGED;
			}
			else{
				rc = strcmp(option,NAME_BINARY);
				if(rc == 0){
					ccsid_new = FT_BINARY;
				}
				else{
					ccsid_new = CCSID_ISO8859_1;
				}
			}
		}
	}
	write_debug_zos("ccsid_new : %04d\n",ccsid_new);

	option = getenv(OPTION_CCSID_ALL);
	if(option == NULL){
		ccsid_all = FT_UNTAGGED;
	}
	else{
		ccsid = __toCcsid(option);
		if(ccsid != 0){
			ccsid_all = ccsid;
		}
		else{
			rc = strcmp(option,NAME_UNTAGGED);
			if(rc == 0){
				ccsid_all = FT_UNTAGGED;
			}
			else{
				rc = strcmp(option,NAME_BINARY);
				if(rc == 0){
					ccsid_all = FT_BINARY;
				}
				else{
					ccsid_all = FT_UNTAGGED;
				}
			}
		}
	}
	write_debug_zos("ccsid_all : %04d\n",ccsid_all);

	option = getenv(OPTION_CCSID_PIPE);
	if(option == NULL){
		ccsid_pipe = CCSID_ISO8859_1;
	}
	else{
		ccsid = __toCcsid(option);
		if(ccsid != 0){
			ccsid_pipe = ccsid;
		}
		else{
			rc = strcmp(option,NAME_UNTAGGED);
			if(rc == 0){
				ccsid_pipe = FT_UNTAGGED;
			}
			else{
				rc = strcmp(option,NAME_BINARY);
				if(rc == 0){
					ccsid_pipe = FT_BINARY;
				}
				else{
					ccsid_pipe = CCSID_ISO8859_1;
				}
			}
		}
	}
	write_debug_zos("ccsid_pipe : %04d\n",ccsid_pipe);

	return 0;
}

static int change_attr_fd(int fd,__ccsid_t ccsid )
{
	attrib_t attrs;
	memset(&attrs,0,sizeof(attrs));
	attrs.att_filetagchg = 1;
	if(ccsid == FT_BINARY)
		attrs.att_filetag.ft_txtflag = 0;
	else
		attrs.att_filetag.ft_txtflag = 1;
	attrs.att_filetag.ft_ccsid = ccsid;
	return __fchattr(fd,&attrs,sizeof(attrs));
}

static int set_attr_fd(int fd,__ccsid_t ccsid)
{
	struct file_tag ft;
	ft.ft_ccsid = ccsid;
	if( ccsid == FT_BINARY){
		ft.ft_txtflag = 0;
	}
	else{
		ft.ft_txtflag = 1;
	}
	ft.ft_deferred = 1;

	return fcntl(fd, F_SETTAG, &ft);
}

static int control_attr_fd(int fd,__ccsid_t ccsid)
{
	struct f_cnvrt cvt = { .pccsid = 0, .fccsid = ccsid, .cvtcmd = SETCVTON };

	return fcntl(fd, F_CONTROL_CVT, &cvt);
}

int set_tag_fd_text(int fd)
{
	int rc;
	struct stat st;
	struct file_tag * tag = &st.st_tag;

	fstat(fd,&st);
	
	/*tag set OK*/
	if(tag->ft_ccsid != FT_UNTAGGED){
		return 0;
	}

	check_env_ccsid();

	if( S_ISFIFO(st.st_mode) ){
		rc = change_attr_fd(fd,ccsid_pipe);
		if(rc == -1){
			return control_attr_fd(fd,ccsid_pipe);
		}
		else{
			return rc;
		}
	}

	if( (S_ISREG(st.st_mode))){
		if( st.st_size == 0){
			/*suppose new file */
			rc = change_attr_fd(fd,ccsid_new);
			if(rc == -1){
				return control_attr_fd(fd,ccsid_new);
			}
			else{
				return rc;
			}
		}
	}	

	if(ccsid_all == FT_UNTAGGED){
		/*set attribute only stream*/
		return control_attr_fd(fd,CCSID_IBM_1047);
	}
	/*set attribute stream and file*/
	rc = change_attr_fd(fd,ccsid_all);
	if(rc == -1){
		return control_attr_fd(fd,ccsid_all);
	}
	return rc;
}

int set_tag_fd_binary(int fd)
{
	struct stat st;
	struct file_tag * tag = &st.st_tag;

	fstat(fd,&st);
	
	/*tag set OK*/
	if(tag->ft_ccsid != FT_UNTAGGED){
		return 0;
	}
	return change_attr_fd(fd,FT_BINARY);
}

static int set_attr_name(char * name,__ccsid_t ccsid )
{
	attrib_t attrs;
	memset(&attrs,0,sizeof(attrs));
	attrs.att_filetagchg = 1;
	if(ccsid == FT_BINARY)
		attrs.att_filetag.ft_txtflag = 0;
	else
		attrs.att_filetag.ft_txtflag = 1;
	attrs.att_filetag.ft_ccsid = ccsid;
	return __chattr(name,&attrs,sizeof(attrs));
}

int set_tag_name(char * name,__ccsid_t ccsid)
{
	int rc;
	struct stat st;
	struct file_tag * tag = &st.st_tag;

	stat(name,&st);

	if(tag->ft_ccsid != FT_UNTAGGED){
		return 0;
	}

	return set_attr_name(name,ccsid);
}

int set_tag_name_text(char * name)
{
	return set_tag_name(name,CCSID_ISO8859_1);
}

int set_tag_name_binary(char * name)
{
	return set_tag_name(name,FT_BINARY);
}

/* **************************************************************** */
