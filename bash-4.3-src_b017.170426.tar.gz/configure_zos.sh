#!/bin/env bash

PRODUCT="bash"
VERSION="4.3"
INSTALL_DIR="/rsusr/rocket/"
SOURCE_DIR="$HOME/ussport/$PRODUCT/$PRODUCT-$VERSION"
BUILD_DIR="$SOURCE_DIR"
#
CPP="xlc -E"
#"-D_EXT -D_UNIX03_SOURCE"
CPPFLAGS="-DUTF8 -D_ENHANCED_ASCII_EXT=0xFFFFFFFF -D_XOPEN_SOURCE_EXTENDED -D_ALL_SOURCE -DNO_MAIN_ENV_ARG -D_OPEN_SYS_FILE_EXT=1 -D_POSIX_SOURCE -D_ISOC99_SOURCE"
CC="xlc"
CFLAGS="-O -qlanglvl=extc99 -qnocsect -qxplink -qenum=int -qascii $CPPFLAGS "
LDFLAGS="-O -qxplink -Wl,ac=1"
CC_FOR_BUILD=""
CFLAGS_FOR_BUILD=""
LDFLAGS_FOR_BUILD=""

#
./configure --prefix="$INSTALL_DIR" --without-bash-malloc\
        --enable-static-link --disable-nls --disable-rpath\
        --with-curses  CC="$CC" CFLAGS="$CFLAGS" CPP="$CPP" CPPFLAGS="$CPPFLAGS" LDFLAGS="$LDFLAGS"

