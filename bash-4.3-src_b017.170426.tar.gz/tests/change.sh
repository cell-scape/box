#!/bin/bash


abso=""

for name in $*
	do
		sed -e "s:^recho :${abso}recho :" $name > ${name}.tmp1
		sed -e "s:^[\t ]*recho :${abso}recho :" ${name}.tmp1 > ${name}.tmp2
		sed -e "s:\`recho :\`${abso}recho :" ${name}.tmp2 > ${name}.tmp3
		sed -e "s:(recho :(${abso}recho :" ${name}.tmp3 > ${name}.tmp4
		sed -e "s: recho : ${abso}recho :" ${name}.tmp4 > ${name}.tmp5

		sed -e "s:^zecho :${abso}zecho :" ${name}.tmp5 > ${name}.tmp6
		sed -e "s:^[\t ]*zecho :${abso}zecho :" ${name}.tmp6 > ${name}.tmp7
		sed -e "s:\`zecho :\`${abso}zecho :" ${name}.tmp7 > ${name}.tmp8
		sed -e "s:(zecho :(${abso}zecho :" ${name}.tmp8 > ${name}.tmp9

		sed -e "s: xcase : ${abso}xcase :" ${name}.tmp9 > ${name}.tmp10

		sed -e "s:\trecho :\t${abso}recho :" ${name}.tmp10 > ${name}.tmp11
		mv ${name}.tmp11 $name
		rm -f ${name}.tmp10
		rm -f ${name}.tmp9
		rm -f ${name}.tmp8
		rm -f ${name}.tmp7
		rm -f ${name}.tmp6
		rm -f ${name}.tmp5
		rm -f ${name}.tmp4
		rm -f ${name}.tmp3
		rm -f ${name}.tmp2
		rm -f ${name}.tmp1
		printf " %s\n"  $name
	done
