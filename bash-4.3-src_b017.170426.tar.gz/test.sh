. <(echo "echo ok")
